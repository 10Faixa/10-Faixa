import React from "react";
import LojaTenis from "./LojaTenis";

export default function App() {
  return <LojaTenis />;
}
