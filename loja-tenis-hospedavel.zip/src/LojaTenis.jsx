import React, { useState } from "react";
// (código omitido aqui para brevidade; conteúdo já conhecido)